package com.achs.voilence_protector.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.achs.voilence_protector.R;

public class DataListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_list_layout);
    }
}
