package com.achs.voilence_protector.Activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.achs.voilence_protector.R;
import com.achs.voilence_protector.util.UserSession;

import static com.achs.voilence_protector.util.UserSession.PREFER_NAME;

public class LoginActivity extends AppCompatActivity {
    private EditText edName, edPassword;
    private Button btnLogin;
    private TextView txtSignup;
    UserSession session;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //user session manager
        session = new UserSession(getApplicationContext());

        edName = findViewById(R.id.ed_name);
        edPassword = findViewById(R.id.ed_password);

        Toast.makeText(getApplicationContext(),
                "User Login Status: " + session.isUserLoggedIn(),
                Toast.LENGTH_LONG).show();

        sharedPreferences = getSharedPreferences(PREFER_NAME, Context.MODE_PRIVATE);


        btnLogin = findViewById(R.id.btn_login);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = edName.getText().toString().trim();
                String password = edPassword.getText().toString().trim();

                //validating if username is filled
                if(username.length() > 0 && password.length() > 0){
                    String uName = null;
                    String uPassword = null;

                    if (sharedPreferences.contains("Name")){
                        uName = sharedPreferences.getString("Name", "");
                    }

                    if (sharedPreferences.contains("Password")){
                        uPassword = sharedPreferences.getString("Password", "");
                    }

                    if (username.equals(uName) && password.equals(uPassword)){

                        session.createUserLoginSession(uName, uPassword);
                        Intent i = new Intent(getApplicationContext(), DashboardActivity.class);
                        startActivity(i);


                        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i);

                        finish();
                    }else{
                        Toast.makeText(getApplicationContext(),
                                "Username/Password is incorrect",
                                Toast.LENGTH_LONG).show();

                    }
                }else{
                    Toast.makeText(getApplicationContext(),
                            "Please enter username and password",
                            Toast.LENGTH_LONG).show();
                }

            }
        });



        txtSignup = findViewById(R.id.txt_signup);
        txtSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(LoginActivity.this, RegistrationActivity.class);
                startActivity(i);
            }
        });
    }
}
