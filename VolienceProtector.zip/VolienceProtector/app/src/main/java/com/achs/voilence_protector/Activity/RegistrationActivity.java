package com.achs.voilence_protector.Activity;


import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.achs.voilence_protector.R;
import com.achs.voilence_protector.util.UserSession;

public class RegistrationActivity extends AppCompatActivity {

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    EditText edNameResister, edEmail, edPhone, edPasswordRegister;//variables for datatype EditText
    Button btnRegister;
    UserSession session;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activit_registration);
        edNameResister= findViewById(R.id.ed_name_register);
        edEmail = findViewById(R.id.ed_email);//initialize
        edPhone = findViewById(R.id.ed_phone);
        edPasswordRegister = findViewById(R.id.ed_password_resister);
        btnRegister = findViewById(R.id.btn_register);
        getSupportActionBar().setTitle("Registration Form");//for name of topmost part of page

        sharedPreferences = getApplicationContext().getSharedPreferences("Reg", 0);
        editor = sharedPreferences.edit();

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = edNameResister.getText().toString();
                String email = edEmail.getText().toString();
                String phone = edPhone.getText().toString();
                String password = edPasswordRegister.getText().toString();
                String vphone = "^[+]?[0-9]{10,13}$";

                if(edNameResister.getText().length() <=0){
                    edNameResister.setError("Field can't be empty");
                }
                else if( edEmail.getText().length()<=0) {
                    if (email.isEmpty()) {
                        edEmail.setError("Field can't be empty");
                    } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                        edEmail.setError("Please enter a valid email address");
                    }

                }
                else if( edPhone.getText().length()<=0) {
                    if (email.isEmpty()) {
                        edPhone.setError("Field can't be empty");
                    } else if ((!phone.matches(vphone))) {
                        edPhone.setError("Invalid phone no ");
                    }

                }else if(edPasswordRegister.getText().length()<=0){
                    edPasswordRegister.setError("Field can't be empty");
                }
                else {

                            // as now we have information in string. Lets stored them with the help of editor
                            editor.putString("Name", name);
                            editor.putString("Email", email);
                            editor.putString("Phone", phone);
                            editor.putString("Password", password);
                            editor.commit();


                            // after saving the value open next activity
                            Intent in = new Intent(RegistrationActivity.this, LoginActivity.class);
                            startActivity(in);

                        }


                    }
        });


    }

//    public void movePage(View v) {//movepage is onclick method for button
//        String stname=edName.getText().toString();
//        String stemail = edEmail.getText().toString();//String(datatype) variable ,inside it store the value that user have tyed
//        String stphone = edPhone.getText().toString();
//        String vphone = "^[+]?[0-9]{10,13}$";
//
//        if(stname.isEmpty()){
//            edName.setError("Field can't be empty");
//        }
//
//        if (stemail.isEmpty()) {
//            edEmail.setError("Field can't be empty");
//        } else if (!Patterns.EMAIL_ADDRESS.matcher(stemail).matches()) {
//            edEmail.setError("Please enter a valid email address");
//        }
//
//         else if (stphone.isEmpty()) {
//            edPhone.setError("Field can't be empty");
//        }
//
//            else if((!stphone.matches(vphone))){
//                edPhone.setError("Invalid phone no ");
//
//        } else {
//            Intent in = new Intent(RegistrationActivity.this, DashboardActivity.class);
//            startActivity(in);
//
//
//        }
//
//
//    }

}

