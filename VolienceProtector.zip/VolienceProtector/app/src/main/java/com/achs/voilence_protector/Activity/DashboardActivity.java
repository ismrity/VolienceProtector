package com.achs.voilence_protector.Activity;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.achs.voilence_protector.Activity.EmergencyContactActivity.EmergencyContactActivity;
import com.achs.voilence_protector.Adapter.ContactAdapter;
import com.achs.voilence_protector.DB.ContactDBHelper;
import com.achs.voilence_protector.util.Contact;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;

import static com.achs.voilence_protector.R.id;
import static com.achs.voilence_protector.R.id.cv_emergency_contacts;
import static com.achs.voilence_protector.R.id.cv_hospital;
import static com.achs.voilence_protector.R.id.cv_laws;
import static com.achs.voilence_protector.R.id.cv_police;
import static com.achs.voilence_protector.R.layout;

public class DashboardActivity extends AppCompatActivity implements View.OnClickListener, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, com.google.android.gms.location.LocationListener{//creates onclick method-view.Onclicklistener specially use for multiple buttons
    private GoogleApiClient mGoogleApiClient;
    private Location mLocation;
    private LocationManager mLocationManager;
    private LocationRequest mLocationRequest;
    private LocationListener listener;
    private long UPDATE_INTERVAL = 2 * 1000;  /* 10 secs */
    private long FASTEST_INTERVAL = 2000; /* 2 sec */
    private LatLng latLng;

    private CardView cvEmergencyContact,cvHospital,cvPolice,cvLaws;
    ImageView imgSOS;
    ContactDBHelper contactDBHelper;
    ContactAdapter mAdapter;
    private ArrayList<Contact> contactList = new ArrayList<>();
    ArrayList<Contact> phoneList = new ArrayList<>();
    ArrayList<Contact> userList = new ArrayList<>();
    Integer sizeOfDB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_dashboard);

        contactDBHelper = new ContactDBHelper(this);
        loadFromDb();
        Log.d("size", String.valueOf(contactList.size()));
        sizeOfDB = contactList.size();

        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();

        mLocationManager = (LocationManager)this.getSystemService(Context.LOCATION_SERVICE);

        checkLocation();

        cvEmergencyContact = findViewById(id.cv_emergency_contacts);//initialize
        cvEmergencyContact.setOnClickListener(this);//for activating button

        cvHospital = findViewById(id.cv_hospital);//R is class which having all id's and views of xml
        cvHospital.setOnClickListener(this);

        cvPolice = findViewById(id.cv_police);
        cvPolice.setOnClickListener(this);

        cvLaws = findViewById(id.cv_laws);
        cvLaws.setOnClickListener(this);


        imgSOS = findViewById(id.img_SOS);//this paste activity itself which is View.Onclicklistener in  class
        imgSOS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                phoneList = contactDBHelper.getPhoneContact();
                userList = contactDBHelper.getUser();

                for (int i = 0; i < phoneList.size(); i++){
                    SendMessage(phoneList.get(i).getPhone(), "Hello. I am"+ userList.get(i).getName() +". I am in danger right now. PLease help me. My location is "+ latLng);

                }
                makePhoneCall();

            }
        });

        //cvLaws is variable and setonclick listener is calling it
        getSupportActionBar().setTitle("Safe Click");


    }

    @Override
    public void onClick(View view) {
        //onclick method for button,view is variable,this method handles click
        Intent i;

        switch (view.getId()){//in order to check which button is clicked,view is variable
            case cv_emergency_contacts:
                i=new Intent(this, EmergencyContactActivity.class);
                startActivity(i);
                break;
            case cv_hospital:
                i=new Intent(this, HospitalActivity.class);
                startActivity(i);
                break;
            case cv_police :
                i=new Intent(this, PoliceActivity.class);
                startActivity(i);
                break;
            case cv_laws :
                i=new Intent(this, LawsActivity.class);
                startActivity(i);
                break;
//            case img_SOS:
//                /*i=new Intent(Intent.ACTION_SENDTO,Uri.parse("sms:9810127170"));
//                i.putExtra("sms_body","Hi there");
//                startActivity(i);
//*/
//                SendMessage("9818876620","Hi, this is test");

        }
        }
    public void SendMessage(String strMobileNo, String strMessage) {
        try {

           SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(strMobileNo, null, strMessage, null, null);

            Toast.makeText(getApplicationContext(), "Your message has been sent",
                    Toast.LENGTH_LONG).show();

        } catch (Exception ex) {
            Toast.makeText(getApplicationContext(), ex.getLocalizedMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    private void makePhoneCall(){
        try{
            Uri callUri = Uri.parse("tel:9860074439");
            Intent callIntent = new Intent(Intent.ACTION_CALL,callUri);
            callIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_NO_USER_ACTION);
            startActivity(callIntent);

        }catch (Exception ex){
            Toast.makeText(getApplicationContext(), ex.getLocalizedMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    private void loadFromDb() {
        try {
            contactList.clear();
            contactList = contactDBHelper.getAllContactString();
            mAdapter = new ContactAdapter(DashboardActivity.this, contactList);
        } catch (Exception e) {
            Log.d("Error==>Db ", e.getLocalizedMessage());
        }
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }

        startLocationUpdates();

        mLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);

        if(mLocation == null){
            startLocationUpdates();
        }
        if (mLocation != null) {

            // mLatitudeTextView.setText(String.valueOf(mLocation.getLatitude()));
            //mLongitudeTextView.setText(String.valueOf(mLocation.getLongitude()));
        } else {
            Toast.makeText(this, "Location not Detected", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onConnectionSuspended(int i) {
//        Log.i(TAG, "Connection Suspended");
        mGoogleApiClient.connect();
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
//        Log.i(TAG, "Connection failed. Error: " + connectionResult.getErrorCode());
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (mGoogleApiClient != null) {
            mGoogleApiClient.connect();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mGoogleApiClient.isConnected()) {
            mGoogleApiClient.disconnect();
        }
    }

    protected void startLocationUpdates() {
        // Create the location request
        mLocationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(UPDATE_INTERVAL)
                .setFastestInterval(FASTEST_INTERVAL);
        // Request location updates
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient,
                mLocationRequest, this);
        Log.d("reque", "--->>>>");
    }

    @Override
    public void onLocationChanged(Location location) {

        String locate = Double.toString(location.getLatitude()) + "," + Double.toString(location.getLongitude());
//        mLatitudeTextView.setText(String.valueOf(location.getLatitude()));
//        mLongitudeTextView.setText(String.valueOf(location.getLongitude() ));
        Toast.makeText(this, locate, Toast.LENGTH_SHORT).show();
        // You can now create a LatLng Object for use with maps
        latLng = new LatLng(location.getLatitude(), location.getLongitude());
    }

    private boolean checkLocation() {
        if(!isLocationEnabled())
            showAlert();
        return isLocationEnabled();
    }

    private void showAlert() {
        final AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Enable Location")
                .setMessage("Your Locations Settings is set to 'Off'.\nPlease Enable Location to " +
                        "use this app")
                .setPositiveButton("Location Settings", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface paramDialogInterface, int paramInt) {

                        Intent myIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        startActivity(myIntent);
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface paramDialogInterface, int paramInt) {

                    }
                });
        dialog.show();
    }

    private boolean isLocationEnabled() {
        mLocationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        return mLocationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                mLocationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }

}








